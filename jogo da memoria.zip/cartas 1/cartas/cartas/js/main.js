$(document).ready(function () {
    // --- Constants ---
    const NUM_CARDS = 16;
    const NUM_PAIRS = NUM_CARDS / 2;
    const SHUFFLE_INTENSITY = 64;
    const HIDE_DELAY = 1000;
    const AI_THINK_TIME = 1000;

    // --- Game State ---
    let board = [];
    let flippedCards = [];
    let matchedPairs = 0;
    let isPlayer1Turn = true;
    let scores = { player1: 0, player2: 0 };
    let isBoardLocked = false;
    let gameMode = null; // 'pvp' or 'pvc'
    let computerKnownCards = new Map(); // AI Memory: Map<cardValue, [index1, index2, ...]>

    // --- DOM Elements Cache ---
    const score1Elem = $('#pontuacaoP1');
    const score2Elem = $('#pontuacaoP2');
    const player1ScoreContainer = $('#player1-score');
    const player2ScoreContainer = $('#player2-score');
    const player2Label = $('#player2-label');
    const gameBoardElem = $('#main');
    const newGameBtn = $('#new-game-btn');
    const gameSetupElem = $('#game-setup');
    const gameContainerElem = $('#game-container');
    const modePvpBtn = $('#mode-pvp');
    const modePvcBtn = $('#mode-pvc');

    /**
     * Creates and shuffles the game board.
     */
    function setupBoard() {
        board = [];
        for (let i = 1; i <= NUM_PAIRS; i++) {
            board.push(i, i);
        }
        for (let i = 0; i < SHUFFLE_INTENSITY; i++) {
            const pos1 = Math.floor(Math.random() * NUM_CARDS);
            const pos2 = Math.floor(Math.random() * NUM_CARDS);
            [board[pos1], board[pos2]] = [board[pos2], board[pos1]];
        }
    }

    /**
     * Renders the card elements on the page.
     */
    function renderBoard() {
        gameBoardElem.empty();
        board.forEach((cardValue, i) => {
            const cardElement = $('<div>').addClass('carta').attr('data-index', i);
            const cardFaceBack = $('<div>').addClass('carta-face carta-verso');
            const cardFaceFront = $('<div>').addClass('carta-face carta-frente').css('background-image', getCardImageURL(cardValue));
            cardElement.append(cardFaceBack, cardFaceFront);
            gameBoardElem.append(cardElement);
        });
    }

    /**
     * Updates the score display and turn indicator on the page.
     */
    function updateUI() {
        score1Elem.text(scores.player1);
        score2Elem.text(scores.player2);
        player1ScoreContainer.toggleClass('active-player', isPlayer1Turn);
        player2ScoreContainer.toggleClass('active-player', !isPlayer1Turn);
    }

    /**
     * Returns the image URL for a given card value.
     */
    function getCardImageURL(cardValue) {
        return `url(assets/${Math.abs(cardValue)}.png)`;
    }

    /**
     * Clears the flipped cards array and unlocks the board for the player.
     */
    function resetFlippedCardsAndUnlock() {
        flippedCards = [];
        isBoardLocked = false;
    }

    /**
     * The core logic for flipping a card, called by player or AI.
     * @param {number} cardIndex The index of the card to flip.
     */
    function doFlip(cardIndex) {
        const cardElement = $(`.carta[data-index="${cardIndex}"]`);

        if (cardElement.hasClass('virada') || board[cardIndex] < 0) {
            return;
        }

        const cardValue = Math.abs(board[cardIndex]);

        // AI "remembers" the card
        if (gameMode === 'pvc') {
            if (!computerKnownCards.has(cardValue)) computerKnownCards.set(cardValue, []);
            if (!computerKnownCards.get(cardValue).includes(cardIndex)) {
                computerKnownCards.get(cardValue).push(cardIndex);
            }
        }

        cardElement.addClass('virada');
        flippedCards.push(cardElement);

        if (flippedCards.length === 2) {
            isBoardLocked = true; // Lock the board while checking for a match
            const card1Index = flippedCards[0].data('index');
            const card2Index = flippedCards[1].data('index');

            if (Math.abs(board[card1Index]) === Math.abs(board[card2Index])) {
                handleMatch();
            } else {
                handleMismatch();
            }
        }
    }

    /**
     * Handles the logic when two flipped cards match.
     */
    function handleMatch() {
        const matchedValue = Math.abs(board[flippedCards[0].data('index')]);

        if (isPlayer1Turn) scores.player1++;
        else scores.player2++;
        
        matchedPairs++;
        updateUI();

        flippedCards.forEach(card => {
            const cardIndex = card.data('index');
            board[cardIndex] = -Math.abs(board[cardIndex]);
        });
        
        // AI: Forget the matched card
        if (gameMode === 'pvc' && computerKnownCards.has(matchedValue)) {
            computerKnownCards.delete(matchedValue);
        }

        if (matchedPairs === NUM_PAIRS) {
            setTimeout(() => {
                const p1 = scores.player1;
                const p2 = scores.player2;
                const p2Name = gameMode === 'pvc' ? "Computador" : "Jogador 2";
                const winner = p1 > p2 ? "Jogador 1" : p2Name;
                const message = p1 === p2 ? "Empate!" : `${winner} venceu!`;
                alert(`Fim de Jogo! ${message}`);
            }, 500);
        } else if (gameMode === 'pvc' && !isPlayer1Turn) {
            // AI got a match, it goes again
            flippedCards = [];
            setTimeout(computerTurn, AI_THINK_TIME);
        } else {
            // Player gets another turn
            resetFlippedCardsAndUnlock();
        }
    }

    /**
     * Handles the logic when two flipped cards do not match.
     */
    function handleMismatch() {
        isBoardLocked = true;
        setTimeout(() => {
            flippedCards.forEach(card => card.removeClass('virada'));
            isPlayer1Turn = !isPlayer1Turn;
            flippedCards = [];
            updateUI();
            if (gameMode === 'pvc' && !isPlayer1Turn) {
                setTimeout(computerTurn, AI_THINK_TIME / 2);
            } else {
                isBoardLocked = false; // Unlock for player
            }
        }, HIDE_DELAY);
    }

    /**
     * Main function to handle a player's card click event.
     */
    function onCardClick() {
        // Only allow clicks if the board is not locked and it's the player's turn
        if (isBoardLocked || (gameMode === 'pvc' && !isPlayer1Turn)) {
            return;
        }
        
        const cardIndex = $(this).data('index');
        doFlip(cardIndex);
    }
    
    /**
     * The AI's logic to take a turn.
     */
    function computerTurn() {
        isBoardLocked = true; // Ensure board is locked for player

        // Strategy 1: Find a guaranteed pair in memory
        let knownPairIndices = null;
        for (const indices of computerKnownCards.values()) {
            if (indices.length === 2) {
                if (board[indices[0]] > 0 && board[indices[1]] > 0) {
                    knownPairIndices = indices;
                    break;
                }
            }
        }

        let cardIndex1, cardIndex2;

        if (knownPairIndices) {
            // AI found a match
            [cardIndex1, cardIndex2] = knownPairIndices;
        } else {
            // Strategy 2: Pick two random available cards
            const availableIndices = [];
            board.forEach((val, index) => { if (val > 0) availableIndices.push(index); });
            
            let index1 = Math.floor(Math.random() * availableIndices.length);
            cardIndex1 = availableIndices.splice(index1, 1)[0];
            
            let index2 = Math.floor(Math.random() * availableIndices.length);
            cardIndex2 = availableIndices.splice(index2, 1)[0];
        }

        // AI "flips" the cards after a short delay
        setTimeout(() => {
            doFlip(cardIndex1);
            setTimeout(() => {
                doFlip(cardIndex2);
            }, 600);
        }, AI_THINK_TIME);
    }

    /**
     * Initializes or resets the game for a given mode.
     */
    function startGame(mode) {
        gameMode = mode;
        player2Label.text(mode === 'pvc' ? 'Computador: ' : 'Jogador 2: ');
        
        gameSetupElem.addClass('hidden');
        gameContainerElem.removeClass('hidden');

        // Reset game state
        matchedPairs = 0;
        isPlayer1Turn = true;
        scores = { player1: 0, player2: 0 };
        isBoardLocked = false;
        flippedCards = [];
        computerKnownCards.clear();

        setupBoard();
        renderBoard();
        updateUI();
    }

    function showMenu() {
        gameContainerElem.addClass('hidden');
        gameSetupElem.removeClass('hidden');
    }

    // --- Event Listeners ---
    gameBoardElem.on('click', '.carta', onCardClick);
    newGameBtn.on('click', showMenu);
    modePvpBtn.on('click', () => startGame('pvp'));
    modePvcBtn.on('click', () => startGame('pvc'));
});